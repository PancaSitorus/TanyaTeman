<?php
class Test_AE_Posts extends WP_UnitTestCase{
	function test_insert_post(){
		$this->assertTrue(false);
	}
}