<?php
require_once dirname( __FILE__ ).'/aecore/index.php';

require_once dirname(__FILE__) . '/customizer.php';
require_once dirname(__FILE__) . '/questions.php';
require_once dirname(__FILE__) . '/members.php';
require_once dirname( __FILE__ ).'/badges.php';
require_once dirname( __FILE__ ).'/section-badges.php';
require_once dirname(__FILE__) . '/template.php';
require_once dirname(__FILE__) . '/theme.php';
require_once dirname(__FILE__) . '/widget.php';
require_once dirname(__FILE__) . '/admin.php';
require_once dirname(__FILE__) . '/front.php';
require_once dirname(__FILE__) . '/vote.php';
require_once dirname(__FILE__) . '/changelog.php';
require_once dirname(__FILE__) . '/social_auth.php';
require_once dirname(__FILE__) . '/pumping/pumping.php';
require_once dirname(__FILE__) . '/poll/poll.php';
// require_once dirname(__FILE__) . '/update.php';